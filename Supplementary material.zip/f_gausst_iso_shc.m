function [W_n] = f_gausst_iso_shc(r,s,n_max,method,method_par)
%%
% F_GAUSST_ISO_SHC calculates the spherical harmonic coefficients of a
% truncated isotropic gaussian averaging filter. For more information see:
%
% Piretzidis D, Sideris MG (2020) Additional methods for the stable
% calculation of isotropic Gaussian filter coefficients: The generalized
% case of a truncated filter kernel. Submitted to Computers & Geosciences. 
%
% HOW: [W_n] = f_gausst_iso_shc(r,s,n_max,method,method_par)
%      [W_n] = f_gausst_iso_shc(r,s,n_max,method)
%
% Input:  r               [1 x 1] averaging radius in km.
%
%         s               [1 x 1] spherical cap radius in km.
%
%         n_max           [1 x 1] maximum degree.
%
%         method                  method for the calculation of filter
%                                 coefficients. Options:
%                                 -'frc'  calculation using forward
%                                         recurrence relation.
%                                 -'frcp' calculation using forward
%                                         recurrence relation with extended
%                                         precision.
%                                 -'tra'  calculation by numerical
%                                         integration using the trapezoidal
%                                         rule.
%                                 -'glq'  calculation by numerical
%                                         integration using the
%                                         Gauss-Legendre quadrature rule.
%                                 -'inv'  calculation using standard
%                                         inversion of tridiagonal matrix.
%                                 -'fwe'  calculation using the forward
%                                         elimination algorithm.
%                                 -'bwe'  calculation using the backward
%                                         elimination algorithm.
%                                 -'thm'  calculation using the Thomas
%                                         algorithm (sweep algorithm).
%                                 -'lud'  calculation using the LU
%                                         decomposition algorithm.
%
%         method_par      [1 x 1] method-specific parameter. For the
%                                 following methods, it denotes:
%                                 -'frcp' number of significant digits.
%                                 -'tra'  number of numerical integration
%                                  'glq'  points.
%                                 -'fwe'  relative accuracy level.
%                                  'thm'
%                                  'lud'
%
% Output: W_n         [n_max x 1] filter coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC
% 07/10/2019

% required m-files: f_legendre_pol.m, lgwt.m

%% Revision history

%% Remarks

%% Input check

if nargin < 4 || nargin > 5; error('Wrong number of input arguments.'); end
if nargin == 4 && max(strcmp(method,{'frc','inv','fwe','bwe','thm','lud'})) == 1
    method_par = NaN;
end

if strcmp(method,'frc') == 0 && strcmp(method,'frcp') == 0 && strcmp(method,'tra') == 0 ...
        && strcmp(method,'glq') == 0 && strcmp(method,'inv') == 0 && strcmp(method,'fwe') == 0 ...
        && strcmp(method,'bwe') == 0 && strcmp(method,'thm') == 0 && strcmp(method,'lud') == 0
    error('<method> should be one of the following: ''frc'', ''frcp'', ''tra'', ''glq'', ''inv'', ''fwe'', ''bwe'', ''thm'', ''lud''.')
end

if nargin == 4 && max(strcmp(method,{'tra','glq'})) == 1
    error('Select the number of numerical integration points in <method_par>.')
end

if nargin == 4 && strcmp(method,'frcp') == 1
    error('Select number of significant digits in <method_par>.')
end

if isscalar(r) == 0
    error('<r> should be scalar.')
end

if isscalar(n_max) == 0
    error('<n_max> should be scalar.')
end

%% Start the algorithm

if strcmp(method,'frcp') == 1
    
    %Set new precision
    digits(method_par)
    
    %Define constants
    R                        = vpa(6378.1363); %Earth's radius [km]
    
    %Calculate b variable
    b                        = vpa(log(2)/(1 - cos(r/R)));
    
    %Calculate spherical cap variable
    y                        = vpa(cos(s/R));
    
    %Calculate exponent of b*(1 - y)
    exp_by                   = exp(b*(1 - y));
    
    %Calculate Legendre polynomials
    P_n                      = f_legendre_pol(n_max + 1,y,'full',method_par);
    
    %Initialize variables
    W_n                      = vpa(zeros(n_max + 1,1));
    
else
    
    %Define constants
    R                        = 6378.1363; %Earth's radius [km]
    
    %Calculate b variable
    b                        = log(2)/(1 - cos(r/R));
    
    %Calculate spherical cap variable
    y                        = cos(s/R);
    
    %Calculate exponent of b*(1 - y)
    exp_by                   = exp(b*(1 - y));
    
    %Calculate Legendre polynomials
    if (strcmp(method,'tra') ~= 1) && (strcmp(method,'glq') ~= 1)
        
        P_n                  = f_legendre_pol(n_max + 1,y,'full');
        
    end
    
    %Initialize variables
    W_n                      = zeros(n_max + 1,1);
    
end

if strcmp(method(1,1:3),'frc') == 1
    
    %Calculate weights for n = 0,1
    W_n(0 + 1,1)             = 1;
    W_n(1 + 1,1)             = (exp_by - y)/(exp_by - 1) - (1/b);
        
    %Calculate weights for n > 1
    for n = 1:n_max - 1
        
        W_n(n + 2,1)         = -((2*n + 1)/b)*W_n(n + 1,1) + W_n(n,1) + (P_n(n,1) - P_n(n + 2,1))/(exp_by - 1);
        
    end
    
elseif strcmp(method,'tra') == 1
    
    %Integration x-axis values
    a                        = linspace(y,1,method_par)';
    
    %Integration step
    da                       = (1 - y)/(method_par - 1);
    
    %Integration weigths
    w_i                      = 2*ones(method_par,1);
    w_i([1,end])             = 1;
    
    %Calculate W(a)
    W_a                      = b.*exp(-b.*(1 - a))./(1 - exp(-b*(1 - y)));
    
    %Calculate Legendre polynomials
    P_n                      = f_legendre_pol(n_max,a,'full');
    
    %Calculate W(a)*P_n
    f_i                      = W_a.*P_n;
    
    %Numerical integration
    W_n                      = da*sum(w_i.*f_i)/2;
    
elseif strcmp(method,'glq') == 1
    
    %Integration nodes and weights
    [a,w_i]                  = lgwt(method_par,-1,1);
    a                        = (1 - y)*a/2 + (1 + y)/2;
    
    %Calculate W(a)
    W_a                      = b.*exp(-b.*(1 - a))./(1 - exp(-b*(1 - y)));
    
    %Calculate Legendre polynomials
    P_n                      = f_legendre_pol(n_max,a,'full');
    
    %Calculate W(a)*P_n
    f_i                      = W_a.*P_n;
    
    %Numerical integration
    W_n                      = (1 - y)*sum(w_i.*f_i)/2;
    
elseif strcmp(method,'inv') == 1
        
    %Calculate weights for n = 0,n_max + 1
    W_n(0 + 1,1)             = 1;
    W_n(n_max + 2,1)         = 0;
    
    %Auxiliary variables
    N                        = (0:n_max)';
        
    %Calculate recurrence coefficients
    aa                       = -1;
    bb                       = (2*N + 1)/b;
    cc                       = 1;
    ff(2:n_max + 1,1)        = (P_n(1:n_max,1) - P_n(3:n_max + 2,1))/(exp_by - 1);
    
    %Create tri-diagonal matrix
    A                        = spdiags([aa*ones(n_max,1),bb(2:end),cc*ones(n_max,1)],-1:1,n_max,n_max);
    
    %Create constant vector
    f                        = ff(2:n_max + 1,1);
    f(1,1)                   = ff(2,1) - aa*W_n(1,1);
    
    %Calculate filter coefficients by inversion
    W_n(2:end - 1,1)         = A\f;
    
    W_n                      = W_n(1:n_max + 1,1);
        
elseif strcmp(method,'fwe') == 1
        
    %Calculate weights for n = 0,n_max + 1
    W_n(0 + 1,1)             = 1;
    W_n(n_max + 2,1)         = 0;
    
    %Auxiliary variables
    N                        = (0:n_max)';
    
    %Calculate recurrence coefficients
    aa                       = -1;
    bb                       = (2*N + 1)/b;
    cc                       = 1;
    ff(2:n_max + 1,1)        = (P_n(1:n_max,1) - P_n(3:n_max + 2,1))/(exp_by - 1);
    
    %Initialize variables
    pp                       = zeros(n_max + 1,1);
    qq                       = zeros(n_max + 1,1);
    
    %Initial conditions
    pp(1,1)                  = 0;
    pp(2,1)                  = 1;
    qq(1,1)                  = W_n(1,1);
    
    %Calculate auxiliary coefficients using forward recurrences
    for i = 1:n_max
        
        pp(i + 2,1)          = (-bb(i + 1,1)*pp(i + 1,1) - aa*pp(i,1))/cc;
        qq(i + 1,1)          = (aa*qq(i,1) - ff(i + 1,1)*pp(i + 1,1))/cc;
        
    end
    
    %Continue forward recurrences until relative accuracy is met
    if isnan(method_par) == 0
        
        %Initialize variables
        s_rel                = 1;
        N_max                = n_max;
        
        while abs(s_rel) > method_par
            
            %Increase maximum degree
            N_max            = N_max + 1;
            
            %Calculate Legendre polynomials (using Bonnet's formula wrt
            %P_{n + 1})
            P_n(N_max + 2,1) = ((2*N_max + 1).*y.*P_n(N_max + 1,1) - N_max.*P_n(N_max,1))./(N_max + 1);
            
            %Calculate recurrence coefficients
            bb_c             = (2*N_max + 1)/b;
            ff(N_max + 1,1)  = (P_n(N_max,1) - P_n(N_max + 2,1))/(exp_by - 1);
            
            %Calculate auxiliary coefficients
            pp(N_max + 2,1)  = (-bb_c*pp(N_max + 1,1) - aa*pp(N_max,1))/cc;
            qq(N_max + 1,1)  = (aa*qq(N_max,1) - ff(N_max + 1,1)*pp(N_max + 1,1))/cc;
            
            %Calculate relative accuracy
            s_rel            = pp(n_max + 1,1)*pp(n_max + 2,1)*qq(N_max + 1,1)/(qq(n_max + 1,1)*pp(N_max + 1,1)*pp(N_max + 2,1));
            
        end
        
        %Update initial condition of W_n for n = n_max + 1
        W_n(N_max + 2,1)     = 0;
        
    elseif isnan(method_par) == 1
        
        N_max                = n_max;
        
    end
    
    %Calculate W_n using backward recurrence
    for i = N_max:-1:1
        
        W_n(i + 1,1)         = (qq(i + 1,1) + pp(i + 1,1)*W_n(i + 2,1))/pp(i + 2,1);
        
    end
    
    W_n                      = W_n(1:n_max + 1,1);
        
elseif strcmp(method,'bwe') == 1
    
    %Calculate weights for n = 0,n_max + 1
    W_n(0 + 1,1)             = 1;
    W_n(n_max + 2,1)         = 0;
    
    %Auxiliary variables
    N                        = (0:n_max)';
        
    %Calculate recurrence coefficients
    aa                       = -1;
    bb                       = (2*N + 1)/b;
    cc                       = 1;
    ff(2:n_max + 1,1)        = (P_n(1:n_max,1) - P_n(3:n_max + 2,1))/(exp_by - 1);
    
    %Initialize variables
    pp                       = zeros(n_max + 1,1);
    qq                       = zeros(n_max + 1,1);
    
    %Initial conditions
    pp(n_max + 2,1)          = 0;
    pp(n_max + 1,1)          = 1;
    qq(n_max + 1,1)          = 0;
    
    %Calculate auxiliary coefficients using backward recurrences
    for i = n_max:-1:1
        
        pp(i,1)              = (-bb(i + 1,1)*pp(i + 1,1) - cc*pp(i + 2,1))/aa;
        qq(i,1)              = (cc*qq(i + 1,1) + ff(i + 1,1)*pp(i + 1,1))/aa;
        
    end
    
    %Calculate W_n using forward recurrence
    for i = 0:n_max - 1
        
        W_n(i + 2,1)         = (pp(i + 2,1)*W_n(i + 1,1) - qq(i + 1,1))/pp(i + 1,1);
        
    end
    
    W_n                      = W_n(1:n_max + 1,1);
    
elseif strcmp(method,'thm') == 1
        
    %Calculate weights for n = 0,n_max + 1
    W_n(0 + 1,1)             = 1;
    W_n(n_max + 2,1)         = 0;
    
    %Auxiliary variables
    N                        = (0:n_max)';
        
    %Calculate recurrence coefficients
    aa                       = -1;
    bb                       = (2*N + 1)/b;
    cc                       = 1;
    ff(2:n_max + 1,1)        = (P_n(1:n_max,1) - P_n(3:n_max + 2,1))/(exp_by - 1);
    
    %Initialize variables
    uu                       = zeros(n_max + 1,1);
    vv                       = zeros(n_max + 1,1);
    
    %Initial conditions
    W_n(1,1)                 = 1;
    W_n(n_max + 2,1)         = 0;
    uu(1,1)                  = 0;
    vv(1,1)                  = W_n(1,1);
    
    %Calculate auxiliary coefficients using forward recurrences
    for i = 1:n_max
        
        uu(i + 1,1)          = -cc/(bb(i + 1,1) + aa*uu(i,1));
        vv(i + 1,1)          = (ff(i + 1,1) - aa*vv(i,1))/(bb(i + 1,1) + aa*uu(i,1));
        
    end
    
    %Continue forward recurrences until relative accuracy is met
    if isnan(method_par) == 0
        
        %Initialize variables
        s_rel                = 1;
        N_max                = n_max;
        f                    = uu(n_max + 1,1);
        
        while abs(s_rel) > method_par
            
            %Increase maximum degree
            N_max            = N_max + 1;
            
            %Calculate Legendre polynomials (using Bonnet's formula wrt
            %P_{n + 1})
            P_n(N_max + 2,1) = ((2*N_max + 1).*y.*P_n(N_max + 1,1) - N_max.*P_n(N_max,1))./(N_max + 1);
            
            %Calculate recurrence coefficients
            bb_c             = (2*N_max + 1)/b;
            ff(N_max + 1,1)  = (P_n(N_max,1) - P_n(N_max + 2,1))/(exp_by - 1);
            
            %Calculate auxiliary coefficients
            uu(N_max + 1,1)  = -cc/(bb_c + aa*uu(N_max,1));
            vv(N_max + 1,1)  = (ff(N_max + 1,1) - aa*vv(N_max,1))/(bb_c + aa*uu(N_max,1));
            f                = f*uu(N_max + 1,1);
            
            %Calculate relative accuracy
            s_rel            = f*vv(N_max + 1,1)/(uu(N_max + 1,1)*vv(n_max + 1,1));
            
        end
        
        %Update initial condition of W_n for n = n_max + 1
        W_n(N_max + 2,1)     = 0;
        
    elseif isnan(method_par) == 1
        
        N_max                = n_max;
        
    end
    
    %Calculate W_n using backward recurrence
    for i = N_max:-1:1
        
        W_n(i + 1,1)         = uu(i + 1,1)*W_n(i + 2,1) + vv(i + 1,1);
        
    end
    
    W_n                      = W_n(1:n_max + 1,1);
        
elseif strcmp(method,'lud') == 1
        
    %Calculate weights for n = 0,n_max + 1
    W_n(0 + 1,1)             = 1;
    W_n(n_max + 2,1)         = 0;
    
    %Auxiliary variables
    N                        = (0:n_max)';
        
    %Calculate recurrence coefficients
    aa                       = -1;
    bb                       = (2*N + 1)/b;
    cc                       = 1;
    ff(2:n_max + 1,1)        = (P_n(1:n_max,1) - P_n(3:n_max + 2,1))/(exp_by - 1);
    
    %Initialize variables
    aa2                      = zeros(n_max + 1,1);
    bb2                      = zeros(n_max + 1,1);
    xx                       = zeros(n_max + 1,1);
    
    %Initial conditions
    bb2(2,1)                 = -bb(2,1);
    xx(2,1)                  = ff(2,1) - aa*W_n(1,1);
    
    %Calculate auxiliary coefficients using forward recurrences
    for i = 2:n_max
        
        aa2(i + 1,1)         = aa/bb2(i,1);
        bb2(i + 1,1)         = -bb(i + 1,1) - aa2(i + 1,1)*cc;
        xx(i + 1,1)          = ff(i + 1,1) + aa2(i + 1,1)*xx(i,1);
        
    end
    
    %Continue forward recurrences until relative accuracy is met
    if isnan(method_par) == 0
        
        %Initialize variables
        s_rel                = 1;
        N_max                = n_max;
        f                    = -1/bb2(n_max + 1,1);
        
        while abs(s_rel) > method_par
            
            %Increase maximum degree
            N_max            = N_max + 1;
            
            %Calculate Legendre polynomials (using Bonnet's formula wrt
            %P_{n + 1})
            P_n(N_max + 2,1) = ((2*N_max + 1).*y.*P_n(N_max + 1,1) - N_max.*P_n(N_max,1))./(N_max + 1);
            
            %Calculate recurrence coefficients
            bb_c             = (2*N_max + 1)/b;
            ff(N_max + 1,1)  = (P_n(N_max,1) - P_n(N_max + 2,1))/(exp_by - 1);
            
            %Calculate auxiliary coefficients
            aa2(N_max + 1,1) = aa/bb2(N_max,1);
            bb2(N_max + 1,1) = -bb_c - aa2(N_max + 1,1)*cc;
            xx(N_max + 1,1)  = ff(N_max + 1,1) + aa2(N_max + 1,1)*xx(N_max,1);
            f                = f*cc/bb2(N_max + 1,1);
            
            %Calculate relative accuracy
            s_rel            = f*xx(N_max + 1,1)*bb2(n_max + 1,1)/xx(n_max + 1,1);
            
        end
        
        %Update initial condition of W_n for n = n_max + 1
        W_n(N_max + 2,1)     = 0;
        
    elseif isnan(method_par) == 1
        
        N_max                = n_max;
        
    end
    
    %Calculate W_n using backward recurrence
    for i = N_max:-1:1
        
        W_n(i + 1,1)         = (cc*W_n(i + 2,1) - xx(i + 1,1))/bb2(i + 1,1);
        
    end
    
    W_n                      = W_n(1:n_max + 1,1);
        
end

%Force output to have a column-vector format
W_n                          = W_n(:);

if strcmp(method,'frcp') == 1
    
    W_n                      = double(W_n);
    
end

end
