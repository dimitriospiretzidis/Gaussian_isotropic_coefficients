function [W_n] = f_gauss_iso_shc(r,n_max,method,point_num)
%%
% F_GAUSS_ISO_SHC calculates the spherical harmonic coefficients of an
% isotropic gaussian averaging filter. For more information see:
%
% Piretzidis D, Sideris MG (2019) Stable recurrent calculation of isotropic
%      Gaussian filter coefficients.
%
% HOW: [W_n] = f_gauss_iso_shc(r,n_max,method,point_num)
%      [W_n] = f_gauss_iso_shc(r,n_max,method)
%
% Input:  r               [1 x 1] averaging radius in km.
%
%         n_max           [1 x 1] maximum degree.
%
%         method                  method for the computation of filter
%                                 coefficients. Options:
%                                 -'frc'  computation using forward
%                                         recurrence relation.
%                                 -'frcp' computation using forward
%                                         recurrence relation with extended
%                                         precision.
%                                 -'tra'  computation by numerical
%                                         integration using the trapezoidal
%                                         rule.
%                                 -'glq'  computation by numerical
%                                         integration using the
%                                         Gauss-Legendre quadrature rule.
%                                 -'brc'  computation using backward
%                                         recurrence algorithm.
%                                 -'brcm' computation using modified
%                                         backward recurrence algorithm.
%                                 -'cfr'  computation using continued
%                                         fraction algorithm.
%                                 -'swp'  computation using sweep
%                                         algorithm.
%
%         point_num       [1 x 1] number of numerical integration points.
%                                 If <method> = 'frcp', then <point_num>
%                                 denotes the number of significant digits.
%
% Output: W_n             [n x 1] filter coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC
% 04/01/2019

% required m-files: f_legendre_pol_rec_fast.m, lgwt.m

%% Revision history

%% Remarks

%% Input check

if nargin < 3 || nargin > 4; error('Wrong number of input arguments.'); end

if strcmp(method,'frc') == 0 && strcmp(method,'frcp') == 0 && strcmp(method,'tra') == 0 ...
        && strcmp(method,'glq') == 0 && strcmp(method,'brc') == 0 && strcmp(method,'brcm') == 0 ...
        && strcmp(method,'cfr') == 0 && strcmp(method,'swp') == 0
    error('<method> should be one of the following: ''frc'', ''frcp'', ''tra'', ''glq'', ''brc'', ''brcm'', ''cfr'', ''swp''.')
end

if nargin == 3 && max(strcmp(method,{'tra','glq'})) == 1
    error('Select <point_num> for the numerical integration.')
end

if nargin == 3 && strcmp(method,'frcp') == 1
    error('Select number of significant digits <point_num>.')
end

if isscalar(r) == 0
    error('<r> should be scalar.')
end

if isscalar(n_max) == 0
    error('<n_max> should be scalar.')
end

%% Start the algorithm

if strcmp(method,'frcp') == 1
    
    %Set new precision
    digits(point_num)
    
    %Define constants
    R                    = vpa(6378.1363); %Earth's radius [km]
    
    %Calculate b variable
    b                    = vpa(log(2)/(1 - cos(r/R)));
    
    %Initialize variables
    W_n                  = vpa(zeros(n_max + 1,1));
    
else
    
    %Define constants
    R                    = 6378.1363; %Earth's radius [km]
    
    %Calculate b variable
    b                    = log(2)/(1 - cos(r/R));
    
    %Initialize variables
    W_n                  = zeros(n_max + 1,1);
    
end

if strcmp(method(1,1:3),'frc') == 1
    
    %Calculate exponent of -2*b
    exp_2b               = exp(-2*b);
    
    %Calculate weights for n = 0,1
    W_n(0 + 1,1)         = 1;
    W_n(1 + 1,1)         = (((1 + exp_2b)/(1 - exp_2b)) - (1/b));
    
    %Calculate weights for n > 1
    for n = 2:n_max
        
        W_n(n + 1,1)     = -((2*n - 1)/b)*W_n(n,1) + W_n(n - 1,1);
        
    end
    
elseif strcmp(method,'tra') == 1
    
    %Integration x-axis values
    a                    = linspace(0,pi,point_num)';
    
    %Integration step
    da                   = pi/(point_num - 1);
    
    %Integration weigths
    w_i                  = 2*ones(point_num,1);
    w_i([1,end])         = 1;
    
    %Calculate W(a)
    W_a                  = b.*exp(-b.*(1-cos(a)))./(1-exp(-2.*b));
    
    %Calculate Legendre polynomials
    P_n                  = f_legendre_pol_rec_fast(n_max,cos(a),'full');
    
    %Calculate W(a)*P_n*sin(a)
    f_i                  = W_a.*P_n.*sin(a);
    
    %Numerical integration
    W_n                  = sum(w_i.*f_i)*da/2;
    
elseif strcmp(method,'glq') == 1
    
    %Integration x-axis values and weights
    [a,w_i]              = lgwt(point_num,-1,1);
    
    %Calculate W(a)
    W_a                  = b.*exp(-b.*(1 - a))./(1-exp(-2.*b));
    
    %Calculate Legendre polynomials
    P_n                  = f_legendre_pol_rec_fast(n_max,a,'full');
    
    %Calculate W(a)*P_n
    f_i                  = W_a.*P_n;
    
    %Numerical integration
    W_n                  = sum(w_i.*f_i);
    
elseif strcmp(method(1,1:3),'brc') == 1
    
    %Calculate weights for n = n_max + 1,n_max
    if strcmp(method,'brcm') == 1
        
        W_n(n_max + 2,1) = 1;
        W_n(n_max + 1,1) = (2*n_max^2 + 3*n_max + 1)/(n_max*b);
        
    else
        
        W_n(n_max + 2,1) = 0;
        W_n(n_max + 1,1) = 1;
        
    end
    
    %Auxiliary variables
    N                    = (0:n_max)';
    
    %Calculate reccurence coefficients
    a_0                  = -1;
    a_1                  = (2*N + 1)/b;
    a_2                  = 1;
    
    %Calculate weights for n < n_max
    for n = n_max:-1:1
        
        W_n(n,1)         = -(a_1(n + 1,1)*W_n(n + 1) + a_2*W_n(n + 2,1))/a_0;
        
    end
    
    %Normalize filter weights
    W_n                  = W_n(1:n_max + 1,1)/W_n(1,1);
    
elseif strcmp(method,'cfr') == 1
    
    %Calculate weights for n = 0
    W_n(0 + 1,1)         = 1;
    
    %Auxiliary variables
    N                    = (0:n_max)';
    
    %Calculate reccurence coefficients
    a_0                  = -1;
    a_1p                 = 2*N/b;
    z                    = -1/b;
    
    %Initialize variable r
    r_n                  = zeros(n_max + 1,1);
    
    %Calculate variable r for n < n_max - 1 using backward recurrence
    for n = n_max:-1:1
        
        r_n(n)           = a_0/(z - a_1p(n + 1) - r_n(n + 1));
        
    end
    
    %Calculate weights for n > 0 using forward recurrence
    for n = 1:n_max
        
        W_n(n + 1,1)     = r_n(n,1)*W_n(n,1);
        
    end
    
elseif strcmp(method,'swp') == 1
    
    %Calculate weights for n = 0,n_max + 1
    W_n(0 + 1,1)         = 1;
    W_n(n_max + 2,1)     = 0;
    
    %Auxiliary variables
    N                    = (0:n_max)';
    
    %Calculate reccurence coefficients
    a_0                  = -1;
    a_1                  = (2*N + 1)/b;
    a_2                  = 1;
    
    %Initialize sweep coefficients
    a_n                  = zeros(n_max + 2,1);
    g_n                  = zeros(n_max + 2,1);
    
    %Calculate sweep coefficients using two-term backwards recurrence
    for n = n_max:-1:1
        
        a_n(n + 1,1)     = -a_0/(a_1(n + 1,1) + a_2*a_n(n + 2,1));
        g_n(n + 1,1)     = -a_2*g_n(n + 2,1)/(a_1(n + 1,1) + a_2*a_n(n + 2,1));
        
    end
    
    %Calculate weights for n < n_max + 1 using forward recurrence
    for n = 1:n_max
        
        W_n(n + 1,1)     = a_n(n + 1,1)*W_n(n,1) + g_n(n + 1,1);
        
    end
    
    W_n(n_max + 2,:)     = [];
    
end

%Force output to have a column-vector format
W_n                      = W_n(:);

if strcmp(method,'frcp') == 1
    
    W_n                  = eval(W_n);
    
end

end
