function [P_n] = f_legendre_pol_rec_fast(n,t,which_degree)
%%
% F_LEGENDRE_POL_REC calculates the Legendre polynomial of degree n using
% recursive formulas.
%
% HOW: [P_n] = f_legendre_pol_rec(n,t,which_degree)
%
% Input:  n                     [1 x 1] degree of Legendre polynomial.
%
%         t                     [k x m] Legendre polynomial input argument;
%                                       usually is cos(theta) or sin(phi).
%         which_degree                  output degrees. Options:
%                                       -'current' returns the Legendre 
%                                                  polynomial of degree
%                                                  <n>.
%                                       -'full'    returns the full 
%                                                  Legendre polynomial
%                                                  matrix.
%
% Output: P_n                   [k x m] Legendre polynomial.
%              or [k x m x (n + 1) x 1]
%
% Dimitrios Piretzidis, Department of Geomatics Engineering UofC
% 31/12/2014

% required m-files: none

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if isscalar(n) == 0
    error('<n> should be scalar.')
end

if strcmp(which_degree,'current') == 0 && strcmp(which_degree,'full') == 0
    error('<which_degree> should be one of the following: ''current'', ''full''.')
end

[i_max,j_max]    = size(t);

if i_max*j_max*(n+1) > 2^31
    error('Too many elements. Consider using f_legendre_pol_rec')
end

%% Start the algorithm

%Initialize the output matrix
P_c              = zeros(i_max,j_max,n + 1,1); 

%Initialize P(0)
P_c(:,:,1,1)     = 1; 

%Initialize P(1)
if n > 0
    
    P_c(:,:,2,1) = t; 

end

%Recursively compute the next elements
for i = 3:(n + 1)
    
    nn           = i - 1;
    P_c(:,:,i,1) = ((2*nn - 1).*t.*P_c(:,:,i - 1,1) - (nn - 1).*P_c(:,:,i - 2,1))./nn;
    
end

if strcmp(which_degree,'full')
    
    P_n          = P_c;
    
elseif strcmp(which_degree,'current')
    
    P_n          = P_c(:,:,n + 1,1);
    
end

P_n              = squeeze(P_n);
