function [W_n] = f_gauss_iso_shc_2(r,n_max,method)
%%
% F_GAUSS_ISO_SHC_2 calculates the spherical harmonic coefficients of an
% isotropic Gaussian filter. For more information see:
%
% Piretzidis D, Sideris MG (2022) Expressions for the calculation of
%      isotropic Gaussian filter kernels in the spherical harmonic domain.
%      Studia Geophysica et Geodaetica, 66(1):1–22,
%      doi:10.1007/s11200-021-0272-9
%
% HOW: [W_n] = f_gauss_iso_shc_2(r,n_max,method)
%
% Input:  r               [1 x 1] averaging radius in km.
%
%         n_max           [1 x 1] maximum degree.
%
%         method                  method for the calculation of filter
%                                 coefficients. Options:
%                                 -'srr'  calculation using second-order
%                                         recurrence relation.
%                                 -'nrr'  calculation using infinite-order
%                                         recurrence relation.
%                                 -'cfe'  calculation using closed-form
%                                         expression.
%                                 -'bf'   calculation using Bessel
%                                         functions of the first kind.
%                                 -'ebf'  calculation using exponentially
%                                         scaled Bessel functions of the
%                                         first kind.
%                                 -'cap'  calculation using approximate
%                                         expression of Chambers (2006).
%                                 -'pap'  calculation using approximate
%                                         expression of Piretzidis &
%                                         Sideris (2022).
%
% Output: W_n    [(n_max +1) x 1] filter coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC
% 02/03/2020

% required m-files: f_legendre_pol.m

%% Revision history

%% Remarks

%% Input check

if nargin ~= 3; error('Wrong number of input arguments.'); end

if ~isscalar(r)
    error('<r> should be scalar.')
end

if ~isscalar(n_max)
    error('<n_max> should be scalar.')
end

if ~strcmp(method,'srr') && ~strcmp(method,'nrr') && ~strcmp(method,'cfe') && ~strcmp(method,'bf') && ~strcmp(method,'ebf') && ~strcmp(method,'cap') && ~strcmp(method,'pap')
    error('<method> should be ''srr'', ''nrr'', ''cfe'', ''bf'', ''ebf'', ''cap'' or ''pap''.')
end

%% Start the algorithm

%Define constants
R                                        = 6378.137; %Earth's radius [km]

%Calculate b variable
b                                        = log(2)/(1 - cos(r/R));

if strcmp(method,'srr')
    
    %Initialize variables
    W_n                                  = zeros(n_max + 1,1);
    W_n(1,1)                             = 1;
    W_n(2,1)                             = coth(b) - 1/b;
    
    %Calculate weights for n > 1
    for n = 1:n_max - 1
        
        W_n(n + 2,1)                     = -((2*n + 1)/b)*W_n(n + 1,1) + W_n(n,1);
        
    end
    
elseif strcmp(method,'nrr')
    
    %Initialize variables
    W_n                                  = zeros(n_max + 1,1);
    W_n(1,1)                             = 1;
    W_n(2,1)                             = coth(b) - 1/b;
    
    for n = 2:n_max
        
        %Get all useful degrees
        d                                = ((n - 1):-2:0)';
        
        %Get all correct coefficients
        W_d                              = W_n(d + 1,1);
        
        %Calculate scale factor
        sf                               = 2*d + 1;
        
        %Calculate sum
        W_sum                            = sum(W_d.*sf);
        
        %Calculate B_{n} parameter
        if mod(n,2) == 0
            
            B_n                          = 1;
            
        else
            
            B_n                          = coth(b);
            
        end
        
        %Calculate filter weights
        W_n(n + 1,1)                     = B_n - W_sum/b;
        
    end
    
elseif strcmp(method,'cfe')
    
    %Initialize variables
    W_n                                  = zeros(n_max + 1,1);
    
    for n = 0:n_max
        
        %Get derivative indices
        k                                = (0:n)';
        
        %Initialize D parameter
        D                                = zeros(n + 1,1);
        
        %Calculate D parameter
        D(mod(n,2) == 0 & mod(k,2) == 0) = 1;
        D(mod(n,2) == 1 & mod(k,2) == 0) = coth(b);
        D(mod(n,2) == 0 & mod(k,2) == 1) = -1;
        D(mod(n,2) == 1 & mod(k,2) == 1) = -coth(b);
        
        %Initialize auxiliary product
        p_k                              = zeros(n + 1,1);
        p_k(1,1)                         = 1;
        
        %Calculate auxiliary product
        for j = 1:n
            
            p_k(j + 1,1)                 = prod((n + 1 - j):(n + j));
            
        end
        
        %Calculate P_n_k parpameter
        P_n_k                            = p_k./((2.^k).*factorial(k));
        
        %Calculate auxiliary parameters
        b_k                              = 1./(b.^k);
        
        %Calculate filter weights
        W_n(n + 1,1)                     = sum(D.*P_n_k.*b_k);
        
    end
    
elseif strcmp(method,'bf')
    
    W_n                                  = besseli((0:n_max)' + 1/2,b,0)/besseli(1/2,b,0);
    
elseif strcmp(method,'ebf')
    
    W_n                                  = besseli((0:n_max)' + 1/2,b,1)/besseli(1/2,b,1);
    
elseif strcmp(method,'cap')
    
    W_n                                  = exp(-(((0:n_max)'*r/R).^2)/(4*log(2)));
    
elseif strcmp(method,'pap')
    
    W_n                                  = exp(-(4*((0:n_max)' + 1/2).^2 - 1)/(8*b));
    
end

end
