function [W_n] = f_gauss_iso_shc(r,n_max,method,method_par)
%%
% F_GAUSS_ISO_SHC calculates the spherical harmonic coefficients of an
% isotropic Gaussian averaging filter. For more information see:
%
% Piretzidis D, Sideris MG (2019) Stable recurrent calculation of isotropic
%      Gaussian filter coefficients. Computers & Geosciences, 133:104303, 
%      doi:10.1016/j.cageo.2019.07.007
%
% HOW: [W_n] = f_gauss_iso_shc(r,n_max,method,method_par)
%      [W_n] = f_gauss_iso_shc(r,n_max,method)
%
% Input:  r               [1 x 1] averaging radius in km.
%
%         n_max           [1 x 1] maximum degree.
%
%         method                  method for the calculation of filter
%                                 coefficients. Options:
%                                 -'frc'  calculation using forward
%                                         recurrence relation.
%                                 -'frcp' calculation using forward
%                                         recurrence relation with extended
%                                         precision.
%                                 -'tra'  calculation by numerical
%                                         integration using the trapezoidal
%                                         rule.
%                                 -'glq'  calculation by numerical
%                                         integration using the
%                                         Gauss-Legendre quadrature rule.
%                                 -'gloq' calculation by numerical
%                                         integration using the
%                                         Gauss-Lobatto quadrature rule.
%                                 -'grq'  calculation by numerical
%                                         integration using the
%                                         Gauss-Radau quadrature rule.
%                                 -'brc'  calculation using the backward
%                                         recurrence algorithm.
%                                 -'brcm' calculation using the modified
%                                         backward recurrence algorithm.
%                                 -'cfr'  calculation using the continued
%                                         fraction algorithm.
%                                 -'swp'  calculation using the sweep
%                                         algorithm (Thomas algorithm in
%                                         backward direction).
%                                 -'thm'  calculation using the Thomas 
%                                         algorithm (in forward direction).
%
%         method_par      [1 x 1] method-specific parameter. For the
%                                 following methods, it denotes:
%                                 -'frcp' number of significant digits.
%                                 -'tra'  number of numerical integration
%                                  'glq'  points.
%                                  'gloq'
%                                  'grq'
%                                 -'thm'  relative accuracy level.
%
% Output: W_n    [(n_max +1) x 1] filter coefficients.
%
% Dimitrios Piretzidis, Department of Geomatics Engineering, UofC
% 04/01/2019

% required m-files: f_legendre_pol.m, lgwt.m, lglnodes.m, lgrnodes.m

%% Revision history

%% Remarks

%% Input check

if nargin < 3 || nargin > 4; error('Wrong number of input arguments.'); end
if nargin == 3 && max(strcmp(method,{'frc','brc','brcm','cfr','swp','thm'})) == 1
    method_par = NaN;
end

if strcmp(method,'frc') == 0 && strcmp(method,'frcp') == 0 && strcmp(method,'tra') == 0 ...
        && strcmp(method,'glq') == 0 && strcmp(method,'gloq') == 0 && strcmp(method,'grq') == 0 ...
        && strcmp(method,'brc') == 0 && strcmp(method,'brcm') == 0 && strcmp(method,'cfr') == 0 ...
        && strcmp(method,'swp') == 0 && strcmp(method,'thm') == 0
    error('<method> should be one of the following: ''frc'', ''frcp'', ''tra'', ''glq'', ''gloq'', ''grq'', ''brc'', ''brcm'', ''cfr'', ''swp'', ''thm''.')
end

if nargin == 3 && max(strcmp(method,{'tra','glq','gloq','grq'})) == 1
    error('Select <method_par> for the numerical integration.')
end

if nargin == 3 && strcmp(method,'frcp') == 1
    error('Select number of significant digits <method_par>.')
end

if isscalar(r) == 0
    error('<r> should be scalar.')
end

if isscalar(n_max) == 0
    error('<n_max> should be scalar.')
end

%% Start the algorithm

if strcmp(method,'frcp') == 1
    
    %Set new precision
    digits(method_par)
    
    %Define constants
    R                        = vpa(6378.1363); %Earth's radius [km]
    
    %Calculate b variable
    b                        = vpa(log(2)/(1 - cos(r/R)));
    
    %Initialize variables
    W_n                      = vpa(zeros(n_max + 1,1));
    
else
    
    %Define constants
    R                        = 6378.1363; %Earth's radius [km]
    
    %Calculate b variable
    b                        = log(2)/(1 - cos(r/R));
    
    %Initialize variables
    W_n                      = zeros(n_max + 1,1);
    
end

if strcmp(method(1,1:3),'frc') == 1
    
    %Calculate exponent of -2*b
    exp_2b                   = exp(-2*b);
    
    %Calculate weights for n = 0,1
    W_n(0 + 1,1)             = 1;
    W_n(1 + 1,1)             = (((1 + exp_2b)/(1 - exp_2b)) - (1/b));
    
    %Calculate weights for n > 1
    for n = 1:n_max - 1
        
        W_n(n + 2,1)         = -((2*n + 1)/b)*W_n(n + 1,1) + W_n(n,1);
        
    end
    
elseif strcmp(method,'tra') == 1
    
    %Integration x-axis values
    a                        = linspace(0,pi,method_par)';
    
    %Integration step
    da                       = pi/(method_par - 1);
    
    %Integration weigths
    w_i                      = 2*ones(method_par,1);
    w_i([1,end])             = 1;
    
    %Calculate W(a)
    W_a                      = b.*exp(-b.*(1-cos(a)))./(1-exp(-2.*b));
    
    %Calculate Legendre polynomials
    P_n                      = f_legendre_pol(n_max,cos(a),'full');
    
    %Calculate W(a)*P_n*sin(a)
    f_i                      = W_a.*P_n.*sin(a);
    
    %Numerical integration
    W_n                      = sum(w_i.*f_i)*da/2;
    
elseif max(strcmp(method,{'glq','gloq','grq'})) == 1
    
    %Integration x-axis values and weights
    if strcmp(method,'glq') == 1
        
        [a,w_i]              = lgwt(method_par,-1,1);
        
    elseif strcmp(method,'gloq') == 1
        
        [a,w_i,~]            = lglnodes(method_par);
        
    elseif strcmp(method,'grq') == 1
        
        [a,w_i,~]            = lgrnodes(method_par);
        
    end
    
    %Calculate W(a)
    W_a                      = b.*exp(-b.*(1 - a))./(1-exp(-2.*b));
    
    %Calculate Legendre polynomials
    P_n                      = f_legendre_pol(n_max,a,'full');
    
    %Calculate W(a)*P_n
    f_i                      = W_a.*P_n;
    
    %Numerical integration
    W_n                      = sum(w_i.*f_i);
    
elseif strcmp(method(1,1:3),'brc') == 1
    
    %Calculate weights for n = n_max + 1,n_max
    if strcmp(method,'brcm') == 1
        
        W_n(n_max + 2,1)     = 1;
        W_n(n_max + 1,1)     = (2*n_max^2 + 3*n_max + 1)/(n_max*b);
        
    else
        
        W_n(n_max + 2,1)     = 0;
        W_n(n_max + 1,1)     = 1;
        
    end
    
    %Auxiliary variables
    N                        = (0:n_max)';
    
    %Calculate recurrence coefficients
    a_0                      = -1;
    a_1                      = (2*N + 1)/b;
    a_2                      = 1;
    
    %Calculate W_n using backward recurrence
    for n = n_max:-1:1
        
        W_n(n,1)             = -(a_1(n + 1,1)*W_n(n + 1,1) + a_2*W_n(n + 2,1))/a_0;
        
    end
    
    %Normalize W_n
    W_n                      = W_n(1:n_max + 1,1)/W_n(1,1);
    
elseif strcmp(method,'cfr') == 1
    
    %Calculate weights for n = 0
    W_n(0 + 1,1)             = 1;
    
    %Auxiliary variables
    N                        = (0:n_max)';
    
    %Calculate recurrence coefficients
    a_0                      = -1;
    a_1                      = (2*N + 1)/b;
    
    %Initialize variables
    r_n                      = zeros(n_max + 1,1);
    
    %Calculate auxiliary coefficients using backward recurrence
    for n = n_max:-1:1
        
        r_n(n,1)             = -a_0/(a_1(n + 1,1) + r_n(n + 1,1));
        
    end
    
    %Calculate W_n using forward recurrence
    for n = 1:n_max
        
        W_n(n + 1,1)         = r_n(n,1)*W_n(n,1);
        
    end
    
elseif strcmp(method,'swp') == 1
    
    %Calculate weights for n = 0,n_max + 1
    W_n(0 + 1,1)             = 1;
    W_n(n_max + 2,1)         = 0;
    
    %Auxiliary variables
    N                        = (0:n_max)';
    
    %Calculate recurrence coefficients
    a_0                      = -1;
    a_1                      = (2*N + 1)/b;
    a_2                      = 1;
    
    %Initialize variables
    a_n                      = zeros(n_max + 2,1);
    g_n                      = zeros(n_max + 2,1);
    
    %Calculate auxiliary coefficients using backwards recurrences
    for n = n_max:-1:1
        
        a_n(n + 1,1)         = -a_0/(a_1(n + 1,1) + a_2*a_n(n + 2,1));
        g_n(n + 1,1)         = -a_2*g_n(n + 2,1)/(a_1(n + 1,1) + a_2*a_n(n + 2,1));
        
    end
    
    %Calculate W_n using forward recurrence
    for n = 1:n_max
        
        W_n(n + 1,1)         = a_n(n + 1,1)*W_n(n,1) + g_n(n + 1,1);
        
    end
    
    W_n                      = W_n(1:n_max + 1,1);
    
elseif strcmp(method,'thm') == 1
    
    %Calculate weights for n = 0,n_max + 1
    W_n(0 + 1,1)             = 1;
    W_n(n_max + 2,1)         = 0;
    
    %Auxiliary variables
    N                        = (0:n_max)';
        
    %Calculate recurrence coefficients
    a_0                      = -1;
    a_1                      = (2*N + 1)/b;
    a_2                      = 1;
    
    %Initialize variables
    u_n                      = zeros(n_max + 1,1);
    v_n                      = zeros(n_max + 1,1);
    
    %Initial conditions
    W_n(1,1)                 = 1;
    W_n(n_max + 2,1)         = 0;
    u_n(1,1)                 = 0;
    v_n(1,1)                 = W_n(1,1);
    
    %Calculate auxiliary coefficients using forward recurrences
    for i = 1:n_max
        
        u_n(i + 1,1)         = -a_2/(a_1(i + 1,1) + a_0*u_n(i,1));
        v_n(i + 1,1)         = -a_0*v_n(i,1)/(a_1(i + 1,1) + a_0*u_n(i,1));
        
    end
    
    %Continue forward recurrences until relative accuracy is met
    if isnan(method_par) == 0
        
        %Initialize variables
        s_rel                = 1;
        N_max                = n_max;
        f                    = u_n(n_max + 1,1);
        
        while abs(s_rel) > method_par
            
            %Increase maximum degree
            N_max            = N_max + 1;
                        
            %Calculate recurrence coefficients
            bb_c             = (2*N_max + 1)/b;
            
            %Calculate auxiliary coefficients
            u_n(N_max + 1,1) = -a_2/(bb_c + a_0*u_n(N_max,1));
            v_n(N_max + 1,1) = -a_0*v_n(N_max,1)/(bb_c + a_0*u_n(N_max,1));
            f                = f*u_n(N_max + 1,1);
            
            %Calculate relative accuracy
            s_rel            = f*v_n(N_max + 1,1)/(u_n(N_max + 1,1)*v_n(n_max + 1,1));
            
        end
        
        %Update initial condition of W_n for n = n_max + 1
        W_n(N_max + 2,1)     = 0;
        
    elseif isnan(method_par) == 1
        
        N_max                = n_max;
        
    end
    
    %Calculate W_n using backward recurrence
    for i = N_max:-1:1
        
        W_n(i + 1,1)         = u_n(i + 1,1)*W_n(i + 2,1) + v_n(i + 1,1);
        
    end
    
    W_n                      = W_n(1:n_max + 1,1);

end

%Force output to have a column-vector format
W_n                          = W_n(:);

if strcmp(method,'frcp') == 1
    
    W_n                      = double(W_n);
    
end

end
